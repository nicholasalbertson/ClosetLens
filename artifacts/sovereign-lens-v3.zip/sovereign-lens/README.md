# Sovereign Lens

Integrated wardrobe intelligence system combining:

- Outfit Lens-style photo detection (Gemini vision)
- Google Photos wardrobe concept
- Sovereign Closet composer + scoring
- BLAIZE / rap aesthetic archive (Volume III) + custom vest library
- Digital Twin constraints (4-inch tunnels, frames, physique, tattoos)

## Quick start (no install)

Open `sovereign-lens-v2.html` in any browser.  
Set a Gemini API key in Settings to enable real vision detection.

## With local backend

```bash
cd sovereign-lens
python3 backend/server.py
```

Then open http://localhost:8080/sovereign-lens-v2.html  
(or serve the HTML statically and point API calls at the server).

Endpoints:

- `GET /api/products`
- `GET /api/archive`
- `POST /api/compose` `{palette, owned_only, twin_bias, budget_max}`
- `POST /api/twin-prompt` `{tunnels, frames, physique, tattoos, notes}`

## Project layout

```
sovereign-lens/
├── sovereign-lens-v2.html      # main interactive prototype
├── sovereign-lens.html         # earlier simulated version
├── data/
│   ├── products.json           # expanded seed (20 items)
│   └── archive.json            # Volume III + vest concepts
├── backend/
│   └── server.py               # stdlib HTTP server + API
├── repo-bootstrap/             # original Sovereign Closet Python package
└── ARCHITECTURE.md
```

## Digital Twin

The twin parameters are non-negotiable canon from the BLAIZE system:

- 4-inch black tunnels (must not be rendered as normal earrings)
- Thick black acetate rectangular frames
- Athletic broad-shouldered tapered-waist physique
- Neck script, hand, and chest tattoos

These bias scoring and generate the exact positive/negative prompts for image models.

## Next production steps

- Wire Google Identity Services + Photos Library API for true personal wardrobe ingest
- Persist items and embeddings (Postgres + pgvector)
- Live affiliate product search with shipping filter
- Custom vest / jewelry CAD references and RFQ flow
