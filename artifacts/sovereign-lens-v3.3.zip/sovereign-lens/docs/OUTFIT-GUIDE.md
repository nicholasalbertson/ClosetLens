# Sovereign Lens Outfit Guide

Derived from the image-series breakdowns (Pink Floral, Moncler Red/Black, White & Red Poolside, Pink OPPS Tactical) plus Volume III rap aesthetic archive, BLAIZE Digital Twin constraints, and the 200-outfit system inventory.

## Core Aesthetic Pillars
- Trap / Drill roadwear
- Hypebeast graphic and camo
- Luxury streetwear (Moncler, LV, Dior, Cartier)
- Tonal Moncler matrix
- Heavy ice (Cubans, tennis, watches)
- Digital Twin non-negotiables: 4-inch black tunnels, thick black acetate frames, athletic physique, neck/hand/chest tattoos

## Four Core Formulas

### Formula 1 — Luxe Streetwear (Moncler + Jordan)
Puffer or gilet (Moncler Maya or tonal high-gloss) over a hoodie (Sp5der, Tech Fleece, or Box Logo). Distressed or stacked denim (AMIRI MX1, Purple Brand P001, Gallery Dept). Matching high-top or chunky Jordan (AJ1, AJ4, AJ11).  
Accessories: iced Cuban or HALO MAX, luxury watch (Rolex / Cartier), thick frames, tunnels.  
Best for: night, content drops, Week 1 tonal matrix.

### Formula 2 — Graphic Heavy Hypebeast
Full camo or matching graphic set (BAPE Shark, Broken Planet, Sp5der). Statement sneaker (AJ1 Chicago, AJ4 Bred, Dunk).  
Crossbody (LV, Goyard). Minimal jewelry or single statement chain.  
Best for: daytime, maximal color, visual density.

### Formula 3 — Y2K / Drill
Jersey or long-sleeve base over hoodie. Baggy or distressed bottoms (Gallery Dept, wide cargo, stacked denim). AF1 or AJ1. Visible PSD waistband, bandana or balaclava for styling only, tunnels + frames.  
Best for: roadwear, drill energy, low-key luxury contrast.

### Formula 4 — Monochromatic Tech
All-black or all-charcoal Nike Tech tracksuit (hoodie + pants). Black puffer vest or fashion gilet. Black/white or triple-black Jordans or AM95.  
Silver ice only. Thick frames.  
Best for: foundation uniform, Decathlon Protocol, high-contrast jewelry focus.

## Image-Series Looks (Documented)

| ID | Look | Key pieces |
|----|------|------------|
| IMG-01 | Pink Floral Set | Pink floral hoodie, black distressed jeans, pink/white AJ1, silver watch |
| IMG-02 | Moncler Red/Black | Red zip hoodie, black Moncler gilet, red sweatpants, CK waistband, black frames, tunnels, diamond chain |
| IMG-03 | White & Red Poolside | Red Moncler vest, white tee, white distressed jeans with red patches, AJ4 red/white, LV crossbody, Cuban |
| IMG-04 | Pink OPPS Tactical | Black graphic tee, pink OPPS tactical vest, black cargo with pink stars, pink/black AJ4, pink Cuban |

## Styling Rules
1. Layering: jersey over hoodie, vest over hoodie, puffer over tech.
2. Jewelry is mandatory — never skip the chain or the tunnels.
3. Silhouette: baggy or stacked bottoms + fitted or oversized top; substantial footwear.
4. Color: black/charcoal as identity base; crimson, royal, ivory, or pink as controlled accents.
5. Grooming: braids or short fringe, tattoos visible, frames on.

## Digital Twin Prompt Snippet
```
full body portrait of athletic male, broad shoulders, tapered waist, 4-inch stretched earlobes with large black tunnels (not earrings), thick black acetate rectangular optical frames, visible neck script and hand tattoos, black luxury streetwear, silver jewelry, chiaroscuro lighting, high detail, cinematic
Negative: small ears, normal earrings, no tattoos, gold jewelry, smiling, soft lighting, feminine
```

## Sourcing Priority (from inventory + P1 matrix)
- High: PSD boxers, Carhartt K87 or Uniqlo tee, Purple Brand or AMIRI denim, AF1 or AJ4, 8–12mm silver Cuban, thick black frames, 4-inch tunnels
- Medium: Moncler Maya or Serrat, Nike Tech set
- Custom / BLAIZE: Milano Ghost vest, Celestial Ice vest, HALO MAX medallion

## Capsule Mapping
- Capsule I Quiet-Luxury Command → Formula 1 + executive tailoring (Eladio/Tony Effe)
- Capsule XIX Nightlife & Formal Trap → heavy ice + leather or tailored black
- Capsule XX Archive & Apex → collector sneakers, vintage references, HALO MAX
- BLAIZE Armory / Noir → custom tactical-fashion vests over tanks or hoodies

All custom vests are fashion-only with no ballistic performance claim.
